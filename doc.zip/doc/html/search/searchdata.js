var indexSectionsWithContent =
{
  0: "acdefgilmoprsuv~",
  1: "cegilmsv",
  2: "acdefgilmoprsuv~",
  3: "p",
  4: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "variables",
  4: "related"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Variables",
  4: "Friends"
};

