var searchData=
[
  ['verifychoice',['VerifyChoice',['../class_manager.html#a84f79439fb06b0cce29ea68b8d5e6e4e',1,'Manager']]],
  ['vertex',['Vertex',['../class_vertex.html',1,'']]]
];
