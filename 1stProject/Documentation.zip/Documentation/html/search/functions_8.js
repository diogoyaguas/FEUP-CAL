var searchData=
[
  ['manager',['Manager',['../class_manager.html#a1658ff9f18e38ccd9cb8b0b371b9c20b',1,'Manager']]]
];
