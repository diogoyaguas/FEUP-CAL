var searchData=
[
  ['operator_3c_3c',['operator&lt;&lt;',['../class_excessao_base.html#af66b68641fe42357c05919fc23e539a7',1,'ExcessaoBase']]]
];
