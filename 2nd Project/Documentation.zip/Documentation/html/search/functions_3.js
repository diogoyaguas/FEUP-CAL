var searchData=
[
  ['excessaobase',['ExcessaoBase',['../class_excessao_base.html#a00a742ebee53edcdc036da6c20990371',1,'ExcessaoBase']]]
];
