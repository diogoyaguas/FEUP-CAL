var searchData=
[
  ['verifychoice',['VerifyChoice',['../class_manager.html#a84f79439fb06b0cce29ea68b8d5e6e4e',1,'Manager::VerifyChoice(string id, vector&lt; Station &gt; stations)'],['../class_manager.html#a762a1a4567d292ade48776de47c1087b',1,'Manager::VerifyChoice(string id, vector&lt; Line &gt; lines)']]],
  ['vertex',['Vertex',['../class_vertex.html',1,'']]]
];
